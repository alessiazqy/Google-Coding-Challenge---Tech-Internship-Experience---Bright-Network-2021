def __init__(self):
    self._video_library = VideoLibrary()
    self.isPlaying = False
    self.Video_Playing = "None"